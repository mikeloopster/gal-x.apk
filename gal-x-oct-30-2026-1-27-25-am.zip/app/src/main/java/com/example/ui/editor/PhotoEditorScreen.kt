package com.example.ui.editor

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.RotateRight
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.request.ImageRequest
import coil.request.SuccessResult
import com.example.data.MediaItem
import com.example.ui.theme.DarkNavyBg
import com.example.ui.theme.NeonBlue
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonTeal
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class EditorMode {
    FILTERS,
    ADJUST,
    TRANSFORM,
    DOODLE_BRUSH,
    NEON_AURA_FX
}

enum class FilterPreset(val label: String, val brightness: Float, val contrast: Float, val saturation: Float, val tintColor: Long) {
    ORIGINAL("Natural", 0f, 1f, 1f, 0x00000000),
    NEON_CYBER("Neon Blue", 5f, 1.3f, 1.4f, 0x3300E5FF),
    SYNTHWAVE("Sunset Violet", 0f, 1.25f, 1.6f, 0x33B026FF),
    MATRIX("Fresh Teal", -5f, 1.35f, 1.3f, 0x3300F5D4),
    NOIR("Classic B&W", 5f, 1.6f, 0f, 0x00000000),
    SUNSET("Golden Hour", 10f, 1.15f, 1.3f, 0x33FFB703),
    VIVID("Vivid Pop", 12f, 1.2f, 1.5f, 0x00000000)
}

data class DrawnPath(
    val path: List<Offset>,
    val color: Color,
    val strokeWidth: Float
)

@Composable
fun PhotoEditorScreen(
    item: MediaItem,
    accentColor: Color,
    onBack: () -> Unit,
    onSaveSuccess: (Bitmap) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }

    val context = LocalContext.current
    var loadedBitmap by remember { mutableStateOf<Bitmap?>(null) }

    var currentMode by remember { mutableStateOf(EditorMode.FILTERS) }
    var selectedPreset by remember { mutableStateOf(FilterPreset.ORIGINAL) }

    // Adjustments
    var brightness by remember { mutableFloatStateOf(0f) }
    var contrast by remember { mutableFloatStateOf(1f) }
    var saturation by remember { mutableFloatStateOf(1f) }
    var temperature by remember { mutableFloatStateOf(0f) }

    // Transforms
    var rotationDegrees by remember { mutableIntStateOf(0) }
    var isFlippedHorizontal by remember { mutableStateOf(false) }

    // Unique Neon Aura FX
    var isNeonAuraEnabled by remember { mutableStateOf(false) }
    var auraIntensity by remember { mutableFloatStateOf(0.6f) }
    var auraColor by remember { mutableStateOf(NeonCyan) }

    // Doodle markup brush
    val drawnPaths = remember { mutableStateListOf<DrawnPath>() }
    var currentDrawColor by remember { mutableStateOf(NeonCyan) }
    var currentBrushWidth by remember { mutableFloatStateOf(14f) }
    var activeStroke = remember { mutableStateListOf<Offset>() }

    // Load original bitmap
    LaunchedEffect(item.uri) {
        withContext(Dispatchers.IO) {
            try {
                val loader = ImageLoader(context)
                val req = ImageRequest.Builder(context)
                    .data(item.uri)
                    .allowHardware(false)
                    .build()
                val result = (loader.execute(req) as? SuccessResult)?.drawable
                if (result is BitmapDrawable) {
                    loadedBitmap = result.bitmap
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkNavyBg)
    ) {
        // Top Action Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.testTag("editor_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = Color.White
                )
            }

            Text(
                text = "Gal X Studio Editor",
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )

            Button(
                onClick = {
                    // Export final processed bitmap
                    val bmp = loadedBitmap ?: Bitmap.createBitmap(800, 800, Bitmap.Config.ARGB_8888)
                    val result = processBitmap(
                        source = bmp,
                        rotation = rotationDegrees,
                        flippedH = isFlippedHorizontal,
                        preset = selectedPreset,
                        userBrightness = brightness,
                        userContrast = contrast,
                        userSaturation = saturation,
                        isAuraEnabled = isNeonAuraEnabled,
                        auraColor = auraColor,
                        auraIntensity = auraIntensity,
                        paths = drawnPaths
                    )
                    onSaveSuccess(result)
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = accentColor,
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.testTag("editor_save_button")
            ) {
                Icon(imageVector = Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Save", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }

        // Center Preview Canvas with interactive markup & adjustments
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(16.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Color.Black)
                .border(1.dp, accentColor.copy(alpha = 0.35f), RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center
        ) {
            // Base Image
            AsyncImage(
                model = item.uri,
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(
                        rotationZ = rotationDegrees.toFloat(),
                        scaleX = if (isFlippedHorizontal) -1f else 1f
                    )
            )

            // Neon Filter / Color Overlay
            if (selectedPreset.tintColor != 0x00000000L) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(selectedPreset.tintColor))
                )
            }

            // Neon Holographic Edge Aura Simulation layer
            if (isNeonAuraEnabled) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .border(
                            width = (auraIntensity * 8f).dp,
                            color = auraColor.copy(alpha = auraIntensity),
                            shape = RoundedCornerShape(14.dp)
                        )
                        .background(
                            androidx.compose.ui.graphics.Brush.radialGradient(
                                colors = listOf(Color.Transparent, auraColor.copy(alpha = auraIntensity * 0.35f))
                            )
                        )
                )
            }

            // Interactive Doodle Brush Canvas
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(currentMode) {
                        if (currentMode == EditorMode.DOODLE_BRUSH) {
                            detectDragGestures(
                                onDragStart = { offset: Offset ->
                                    activeStroke.clear()
                                    activeStroke.add(offset)
                                },
                                onDrag = { change: PointerInputChange, _ ->
                                    change.consume()
                                    activeStroke.add(change.position)
                                },
                                onDragEnd = {
                                    if (activeStroke.isNotEmpty()) {
                                        drawnPaths.add(
                                            DrawnPath(
                                                path = activeStroke.toList(),
                                                color = currentDrawColor,
                                                strokeWidth = currentBrushWidth
                                            )
                                        )
                                        activeStroke.clear()
                                    }
                                }
                            )
                        }
                    }
            ) {
                // Draw completed strokes with neon glow effect
                drawnPaths.forEach { stroke ->
                    if (stroke.path.size > 1) {
                        val path = Path().apply {
                            moveTo(stroke.path[0].x, stroke.path[0].y)
                            for (i in 1 until stroke.path.size) {
                                lineTo(stroke.path[i].x, stroke.path[i].y)
                            }
                        }
                        // Outer glow
                        drawPath(
                            path = path,
                            color = stroke.color.copy(alpha = 0.4f),
                            style = Stroke(
                                width = stroke.strokeWidth * 1.8f,
                                cap = StrokeCap.Round,
                                join = StrokeJoin.Round
                            )
                        )
                        // Inner bright core
                        drawPath(
                            path = path,
                            color = stroke.color,
                            style = Stroke(
                                width = stroke.strokeWidth,
                                cap = StrokeCap.Round,
                                join = StrokeJoin.Round
                            )
                        )
                    }
                }

                // Draw currently active stroke
                if (activeStroke.size > 1) {
                    val path = Path().apply {
                        moveTo(activeStroke[0].x, activeStroke[0].y)
                        for (i in 1 until activeStroke.size) {
                            lineTo(activeStroke[i].x, activeStroke[i].y)
                        }
                    }
                    drawPath(
                        path = path,
                        color = currentDrawColor.copy(alpha = 0.4f),
                        style = Stroke(
                            width = currentBrushWidth * 1.8f,
                            cap = StrokeCap.Round,
                            join = StrokeJoin.Round
                        )
                    )
                    drawPath(
                        path = path,
                        color = currentDrawColor,
                        style = Stroke(
                            width = currentBrushWidth,
                            cap = StrokeCap.Round,
                            join = StrokeJoin.Round
                        )
                    )
                }
            }
        }

        // Sub-tool Controls Panel (Dynamic based on selected mode)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(SurfaceDark)
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            when (currentMode) {
                EditorMode.FILTERS -> {
                    // Filters row
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(FilterPreset.values()) { preset ->
                            val isSelected = selectedPreset == preset
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (isSelected) accentColor.copy(alpha = 0.2f) else SurfaceCard)
                                    .border(
                                        width = if (isSelected) 1.5.dp else 0.5.dp,
                                        color = if (isSelected) accentColor else Color(0x3300E5FF),
                                        shape = RoundedCornerShape(12.dp)
                                    )
                                    .clickable { selectedPreset = preset }
                                    .padding(horizontal = 14.dp, vertical = 10.dp)
                                    .testTag("filter_preset_${preset.name}")
                            ) {
                                Text(
                                    text = preset.label,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) accentColor else TextPrimary
                                )
                            }
                        }
                    }
                }

                EditorMode.ADJUST -> {
                    // Sliders for Brightness, Contrast, Saturation
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "Brightness", fontSize = 11.sp, color = TextSecondary, modifier = Modifier.width(70.dp))
                            Slider(
                                value = brightness,
                                onValueChange = { brightness = it },
                                valueRange = -50f..50f,
                                colors = SliderDefaults.colors(thumbColor = accentColor, activeTrackColor = accentColor),
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "Contrast", fontSize = 11.sp, color = TextSecondary, modifier = Modifier.width(70.dp))
                            Slider(
                                value = contrast,
                                onValueChange = { contrast = it },
                                valueRange = 0.5f..2.0f,
                                colors = SliderDefaults.colors(thumbColor = accentColor, activeTrackColor = accentColor),
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "Saturation", fontSize = 11.sp, color = TextSecondary, modifier = Modifier.width(70.dp))
                            Slider(
                                value = saturation,
                                onValueChange = { saturation = it },
                                valueRange = 0f..2.5f,
                                colors = SliderDefaults.colors(thumbColor = accentColor, activeTrackColor = accentColor),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                EditorMode.TRANSFORM -> {
                    // Rotate and Flip buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = { rotationDegrees = (rotationDegrees + 90) % 360 },
                            colors = ButtonDefaults.buttonColors(containerColor = SurfaceCard),
                            shape = RoundedCornerShape(12.dp),
                            border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(accentColor.copy(alpha = 0.5f))),
                            modifier = Modifier.testTag("rotate_90_button")
                        ) {
                            Icon(imageVector = Icons.AutoMirrored.Filled.RotateRight, contentDescription = null, tint = accentColor)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Rotate 90°", color = TextPrimary)
                        }

                        Button(
                            onClick = { isFlippedHorizontal = !isFlippedHorizontal },
                            colors = ButtonDefaults.buttonColors(containerColor = SurfaceCard),
                            shape = RoundedCornerShape(12.dp),
                            border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(accentColor.copy(alpha = 0.5f))),
                            modifier = Modifier.testTag("flip_horizontal_button")
                        ) {
                            Icon(imageVector = Icons.Default.Flip, contentDescription = null, tint = accentColor)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Flip Horiz", color = TextPrimary)
                        }
                    }
                }

                EditorMode.DOODLE_BRUSH -> {
                    // Brush color swatches & clear
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val colors = listOf(NeonCyan, NeonPink, NeonViolet, NeonTeal, Color(0xFFFFB703), Color.White)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                colors.forEach { c ->
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .clip(CircleShape)
                                            .background(c)
                                            .border(
                                                width = if (currentDrawColor == c) 2.dp else 0.5.dp,
                                                color = if (currentDrawColor == c) Color.White else Color.Black,
                                                shape = CircleShape
                                            )
                                            .clickable { currentDrawColor = c }
                                    )
                                }
                            }

                            Text(
                                text = "Clear All",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFFF4B6E),
                                modifier = Modifier
                                    .clickable { drawnPaths.clear() }
                                    .padding(4.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "Brush Size", fontSize = 11.sp, color = TextSecondary, modifier = Modifier.width(70.dp))
                            Slider(
                                value = currentBrushWidth,
                                onValueChange = { currentBrushWidth = it },
                                valueRange = 4f..40f,
                                colors = SliderDefaults.colors(thumbColor = accentColor, activeTrackColor = accentColor),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                EditorMode.NEON_AURA_FX -> {
                    // Holographic Edge Aura controls
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Holographic Cyber Aura",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Button(
                                onClick = { isNeonAuraEnabled = !isNeonAuraEnabled },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isNeonAuraEnabled) NeonCyan else SurfaceCard
                                ),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(
                                    text = if (isNeonAuraEnabled) "Active" else "Disabled",
                                    color = if (isNeonAuraEnabled) Color.Black else TextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "Glow Intensity", fontSize = 11.sp, color = TextSecondary, modifier = Modifier.width(90.dp))
                            Slider(
                                value = auraIntensity,
                                onValueChange = { auraIntensity = it },
                                valueRange = 0.1f..1.0f,
                                colors = SliderDefaults.colors(thumbColor = auraColor, activeTrackColor = auraColor),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        // Bottom Mode Tabs Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF070B18))
                .navigationBarsPadding()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            EditorModeItem(
                label = "Filters",
                icon = Icons.Default.AutoAwesome,
                isSelected = currentMode == EditorMode.FILTERS,
                accentColor = accentColor,
                onClick = { currentMode = EditorMode.FILTERS }
            )

            EditorModeItem(
                label = "Adjust",
                icon = Icons.Default.Tune,
                isSelected = currentMode == EditorMode.ADJUST,
                accentColor = accentColor,
                onClick = { currentMode = EditorMode.ADJUST }
            )

            EditorModeItem(
                label = "Transform",
                icon = Icons.Default.Crop,
                isSelected = currentMode == EditorMode.TRANSFORM,
                accentColor = accentColor,
                onClick = { currentMode = EditorMode.TRANSFORM }
            )

            EditorModeItem(
                label = "Neon Brush",
                icon = Icons.Default.Brush,
                isSelected = currentMode == EditorMode.DOODLE_BRUSH,
                accentColor = accentColor,
                onClick = { currentMode = EditorMode.DOODLE_BRUSH }
            )

            EditorModeItem(
                label = "Magic Glow",
                icon = Icons.Default.AutoAwesome,
                isSelected = currentMode == EditorMode.NEON_AURA_FX,
                accentColor = accentColor,
                onClick = { currentMode = EditorMode.NEON_AURA_FX }
            )
        }
    }
}

@Composable
fun EditorModeItem(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    accentColor: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (isSelected) accentColor else TextMuted,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = if (isSelected) accentColor else TextMuted
        )
    }
}

fun processBitmap(
    source: Bitmap,
    rotation: Int,
    flippedH: Boolean,
    preset: FilterPreset,
    userBrightness: Float,
    userContrast: Float,
    userSaturation: Float,
    isAuraEnabled: Boolean,
    auraColor: Color,
    auraIntensity: Float,
    paths: List<DrawnPath>
): Bitmap {
    val matrix = android.graphics.Matrix()
    if (rotation != 0) matrix.postRotate(rotation.toFloat())
    if (flippedH) matrix.postScale(-1f, 1f)

    val transformed = Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
    val output = Bitmap.createBitmap(transformed.width, transformed.height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(output)

    val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    // Color matrix for brightness, contrast, saturation
    val cm = ColorMatrix()
    val totalBrightness = userBrightness + preset.brightness
    val totalContrast = userContrast * preset.contrast
    val totalSat = userSaturation * preset.saturation

    cm.setSaturation(totalSat)

    // Scale contrast
    val scale = totalContrast
    val translate = (1f - scale) * 128f + totalBrightness
    val contrastMatrix = ColorMatrix(
        floatArrayOf(
            scale, 0f, 0f, 0f, translate,
            0f, scale, 0f, 0f, translate,
            0f, 0f, scale, 0f, translate,
            0f, 0f, 0f, 1f, 0f
        )
    )
    cm.postConcat(contrastMatrix)
    paint.colorFilter = ColorMatrixColorFilter(cm)

    canvas.drawBitmap(transformed, 0f, 0f, paint)

    // Tint filter overlay if preset has one
    if (preset.tintColor != 0x00000000L) {
        val tintPaint = Paint().apply {
            color = preset.tintColor.toInt()
        }
        canvas.drawRect(0f, 0f, output.width.toFloat(), output.height.toFloat(), tintPaint)
    }

    // Aura border if enabled
    if (isAuraEnabled) {
        val auraPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = auraColor.toArgb()
            strokeWidth = auraIntensity * 24f
            alpha = (auraIntensity * 200).toInt()
        }
        canvas.drawRect(0f, 0f, output.width.toFloat(), output.height.toFloat(), auraPaint)
    }

    // Render brush paths onto bitmap
    paths.forEach { stroke ->
        if (stroke.path.size > 1) {
            val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = stroke.color.toArgb()
                style = Paint.Style.STROKE
                strokeCap = Paint.Cap.ROUND
                strokeJoin = Paint.Join.ROUND
                strokeWidth = stroke.strokeWidth * (output.width.toFloat() / 400f).coerceIn(1f, 3f)
            }
            val path = android.graphics.Path()
            // Map relative coordinates to output canvas
            val startX = stroke.path[0].x * (output.width.toFloat() / 800f).coerceAtLeast(1f)
            val startY = stroke.path[0].y * (output.height.toFloat() / 800f).coerceAtLeast(1f)
            path.moveTo(startX, startY)
            for (i in 1 until stroke.path.size) {
                val px = stroke.path[i].x * (output.width.toFloat() / 800f).coerceAtLeast(1f)
                val py = stroke.path[i].y * (output.height.toFloat() / 800f).coerceAtLeast(1f)
                path.lineTo(px, py)
            }
            canvas.drawPath(path, strokePaint)
        }
    }

    return output
}
