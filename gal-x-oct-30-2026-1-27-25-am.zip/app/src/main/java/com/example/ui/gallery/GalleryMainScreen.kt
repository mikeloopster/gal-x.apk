package com.example.ui.gallery

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.example.data.MediaItem
import com.example.ui.GalXUiState
import com.example.ui.GalXViewModel
import com.example.ui.GalleryTab
import com.example.ui.Screen
import com.example.ui.settings.SettingsDialog
import com.example.ui.theme.DarkNavyBg

@Composable
fun GalleryMainScreen(
    viewModel: GalXViewModel,
    uiState: GalXUiState,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    var showSettingsDialog by remember { mutableStateOf(false) }

    // Modern Android Photo Picker launcher
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris ->
        if (uris.isNotEmpty()) {
            viewModel.addImportedMedia(uris)
        }
    }

    // Runtime Permission Launcher
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissionsMap ->
        val isGranted = permissionsMap.values.any { it }
        viewModel.setStoragePermissionGranted(isGranted)
        if (isGranted) {
            viewModel.loadMedia()
        }
    }

    fun requestStorageAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.READ_MEDIA_IMAGES,
                    Manifest.permission.READ_MEDIA_VIDEO
                )
            )
        } else {
            permissionLauncher.launch(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE))
        }
    }

    // Check and request phone storage permissions automatically at launch
    LaunchedEffect(Unit) {
        val hasPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED ||
                    ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        }
        viewModel.setStoragePermissionGranted(hasPermission)
        if (!hasPermission) {
            requestStorageAccess()
        }
    }

    // Display status message if present
    LaunchedEffect(uiState.statusMessage) {
        uiState.statusMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearToast()
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = DarkNavyBg,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            GalleryTopBar(
                searchQuery = uiState.searchQuery,
                onSearchQueryChanged = { viewModel.onSearchQueryChanged(it) },
                selectedFilter = uiState.selectedFilter,
                onFilterChanged = { viewModel.onFilterChanged(it) },
                viewDensity = uiState.viewDensity,
                onDensityChanged = { viewModel.setDensity(it) },
                isSelectionMode = uiState.isSelectionMode,
                selectedCount = uiState.selectedItemIds.size,
                onDeleteSelected = { viewModel.deleteSelected() },
                onClearSelection = { viewModel.clearSelection() },
                onImportMedia = {
                    photoPickerLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
                    )
                },
                onOpenSettings = { showSettingsDialog = true },
                accentColor = uiState.accentColor
            )
        },
        bottomBar = {
            if (!uiState.isSelectionMode) {
                GalleryBottomBar(
                    currentTab = uiState.currentTab,
                    onTabSelected = { viewModel.setTab(it) },
                    accentColor = uiState.accentColor
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(DarkNavyBg)
        ) {
            when (uiState.currentTab) {
                GalleryTab.PICTURES -> {
                    TimelineTab(
                        timelineGroups = uiState.timelineGroups,
                        viewDensity = uiState.viewDensity,
                        selectedItemIds = uiState.selectedItemIds,
                        isSelectionMode = uiState.isSelectionMode,
                        accentColor = uiState.accentColor,
                        onItemClick = { item ->
                            if (uiState.isSelectionMode) {
                                viewModel.toggleItemSelection(item.id)
                            } else {
                                viewModel.navigateTo(Screen.Viewer(item))
                            }
                        },
                        onItemLongClick = { item ->
                            viewModel.toggleItemSelection(item.id)
                        },
                        onImportClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
                            )
                        },
                        onRequestPermissionClick = { requestStorageAccess() },
                        isStoragePermissionGranted = uiState.isStoragePermissionGranted
                    )
                }

                GalleryTab.ALBUMS -> {
                    AlbumsTab(
                        albums = uiState.albums,
                        accentColor = uiState.accentColor,
                        onAlbumClick = { albumName ->
                            viewModel.navigateTo(Screen.AlbumDetail(albumName))
                        },
                        onOpenVaultClick = {
                            viewModel.navigateTo(Screen.Vault)
                        }
                    )
                }

                GalleryTab.STORIES -> {
                    StoriesTab(
                        allMedia = uiState.allMedia,
                        accentColor = uiState.accentColor,
                        onViewItem = { viewModel.navigateTo(Screen.Viewer(it)) },
                        onEditItem = { viewModel.navigateTo(Screen.Editor(it)) }
                    )
                }

                GalleryTab.STUDIO -> {
                    StudioTab(
                        mediaList = uiState.allMedia,
                        accentColor = uiState.accentColor,
                        onLaunchEditor = { viewModel.navigateTo(Screen.Editor(it)) },
                        onOpenVault = { viewModel.navigateTo(Screen.Vault) }
                    )
                }
            }
        }

        if (showSettingsDialog) {
            SettingsDialog(
                currentAccent = uiState.accentColor,
                onAccentSelected = { viewModel.setAccentColor(it) },
                currentDensity = uiState.viewDensity,
                onDensitySelected = { viewModel.setDensity(it) },
                totalPhotos = uiState.allMedia.count { !it.isVideo },
                totalVideos = uiState.allMedia.count { it.isVideo },
                onDismiss = { showSettingsDialog = false }
            )
        }
    }
}
