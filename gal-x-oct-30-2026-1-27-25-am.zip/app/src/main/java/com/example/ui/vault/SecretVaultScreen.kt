package com.example.ui.vault

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MediaItem
import com.example.ui.gallery.MediaCard
import com.example.ui.theme.GalXAccentPurple
import com.example.ui.theme.GalXBorderLight
import com.example.ui.theme.GalXDeepNavy
import com.example.ui.theme.GalXSurfaceCard
import com.example.ui.theme.GalXTextMuted
import com.example.ui.theme.GalXTextPrimary
import com.example.ui.theme.GalXTextSecondary

@Composable
fun SecretVaultScreen(
    allMedia: List<MediaItem>,
    isUnlocked: Boolean,
    onUnlock: (String) -> Boolean,
    onLock: () -> Unit,
    onBack: () -> Unit,
    onItemClick: (MediaItem) -> Unit,
    onToggleVault: (MediaItem) -> Unit,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }

    var enteredPin by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf(false) }

    val vaultedItems = allMedia.filter { it.isVaulted }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(GalXDeepNavy)
    ) {
        // Top Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.testTag("vault_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = Color.White
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = GalXAccentPurple,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Private Album",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = GalXTextPrimary
                )
            }

            if (isUnlocked) {
                IconButton(onClick = onLock) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Lock",
                        tint = GalXAccentPurple
                    )
                }
            } else {
                Spacer(modifier = Modifier.width(48.dp))
            }
        }

        if (!isUnlocked) {
            // Friendly Passcode Keypad
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(76.dp)
                        .clip(CircleShape)
                        .background(GalXAccentPurple.copy(alpha = 0.15f))
                        .border(1.5.dp, GalXAccentPurple.copy(alpha = 0.6f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        tint = GalXAccentPurple,
                        modifier = Modifier.size(36.dp)
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                Text(
                    text = "Enter Passcode",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = GalXTextPrimary
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = if (pinError) "Incorrect passcode, try default: 1234" else "Default Passcode: 1234",
                    fontSize = 12.sp,
                    color = if (pinError) Color(0xFFFF5277) else GalXTextSecondary
                )

                Spacer(modifier = Modifier.height(28.dp))

                // Passcode Dots
                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    repeat(4) { idx ->
                        val isFilled = idx < enteredPin.length
                        Box(
                            modifier = Modifier
                                .size(14.dp)
                                .clip(CircleShape)
                                .background(
                                    if (isFilled) GalXAccentPurple else Color(0xFF1E293B)
                                )
                                .border(
                                    1.dp,
                                    if (isFilled) Color.White else GalXBorderLight,
                                    CircleShape
                                )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(36.dp))

                // Numeric Keypad
                val keypad = listOf(
                    listOf("1", "2", "3"),
                    listOf("4", "5", "6"),
                    listOf("7", "8", "9"),
                    listOf("DEL", "0", "OK")
                )

                Column(
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    keypad.forEach { row ->
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(22.dp)
                        ) {
                            row.forEach { key ->
                                Box(
                                    modifier = Modifier
                                        .size(68.dp)
                                        .clip(CircleShape)
                                        .background(GalXSurfaceCard)
                                        .border(
                                            0.6.dp,
                                            GalXBorderLight,
                                            CircleShape
                                        )
                                        .clickable {
                                            when (key) {
                                                "DEL" -> {
                                                    if (enteredPin.isNotEmpty()) {
                                                        enteredPin = enteredPin.dropLast(1)
                                                        pinError = false
                                                    }
                                                }
                                                "OK" -> {
                                                    val success = onUnlock(enteredPin)
                                                    if (!success) {
                                                        pinError = true
                                                        enteredPin = ""
                                                    }
                                                }
                                                else -> {
                                                    if (enteredPin.length < 4) {
                                                        enteredPin += key
                                                        pinError = false
                                                        if (enteredPin.length == 4) {
                                                            val success = onUnlock(enteredPin)
                                                            if (!success) {
                                                                pinError = true
                                                                enteredPin = ""
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        .testTag("pin_key_$key"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (key == "DEL") {
                                        Icon(
                                            imageVector = Icons.AutoMirrored.Filled.Backspace,
                                            contentDescription = "Delete",
                                            tint = Color.White,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    } else if (key == "OK") {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = "Unlock",
                                            tint = GalXAccentPurple,
                                            modifier = Modifier.size(24.dp)
                                        )
                                    } else {
                                        Text(
                                            text = key,
                                            fontSize = 22.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = GalXTextPrimary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Unlocked View
            if (vaultedItems.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(28.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(GalXAccentPurple.copy(alpha = 0.2f))
                                .border(1.dp, GalXAccentPurple, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.LockOpen,
                                contentDescription = null,
                                tint = GalXAccentPurple,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "No Hidden Photos",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = GalXTextPrimary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "To move photos here, open any picture in Gal X and tap the 'Hide' button.",
                            fontSize = 13.sp,
                            color = GalXTextSecondary,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(vaultedItems, key = { it.id }) { item ->
                        MediaCard(
                            item = item,
                            isSelected = false,
                            isSelectionMode = false,
                            accentColor = GalXAccentPurple,
                            onClick = { onItemClick(item) },
                            onLongClick = { onToggleVault(item) }
                        )
                    }
                }
            }
        }
    }
}
