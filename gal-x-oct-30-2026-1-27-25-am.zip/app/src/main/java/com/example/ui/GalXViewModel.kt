package com.example.ui

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.MediaAlbum
import com.example.data.MediaFilterType
import com.example.data.MediaItem
import com.example.data.MediaRepository
import com.example.data.TimelineGroup
import com.example.data.ViewDensity
import com.example.ui.theme.NeonCyan
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed class Screen {
    data object Splash : Screen()
    data object Gallery : Screen()
    data class Viewer(val item: MediaItem) : Screen()
    data class Editor(val item: MediaItem) : Screen()
    data class AlbumDetail(val albumName: String) : Screen()
    data object Vault : Screen()
}

enum class GalleryTab {
    PICTURES,
    ALBUMS,
    STORIES,
    STUDIO
}

data class GalXUiState(
    val currentScreen: Screen = Screen.Splash,
    val currentTab: GalleryTab = GalleryTab.PICTURES,
    val allMedia: List<MediaItem> = emptyList(),
    val filteredMedia: List<MediaItem> = emptyList(),
    val timelineGroups: List<TimelineGroup> = emptyList(),
    val albums: List<MediaAlbum> = emptyList(),
    val selectedFilter: MediaFilterType = MediaFilterType.ALL,
    val searchQuery: String = "",
    val viewDensity: ViewDensity = ViewDensity.STANDARD,
    val selectedItemIds: Set<Long> = emptySet(),
    val isSelectionMode: Boolean = false,
    val isStoragePermissionGranted: Boolean = false,
    val isLoading: Boolean = true,
    val accentColor: Color = NeonCyan,
    val statusMessage: String? = null,
    val vaultPin: String = "1234",
    val isVaultUnlocked: Boolean = false
)

class GalXViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = MediaRepository(application.applicationContext)

    private val _uiState = MutableStateFlow(GalXUiState())
    val uiState: StateFlow<GalXUiState> = _uiState.asStateFlow()

    init {
        loadMedia()
    }

    fun setStoragePermissionGranted(granted: Boolean) {
        _uiState.update { it.copy(isStoragePermissionGranted = granted) }
        loadMedia()
    }

    fun loadMedia() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val media = repository.loadDeviceMedia()
            updateMediaCollections(media)
            _uiState.update { it.copy(isLoading = false) }
        }
    }

    private fun updateMediaCollections(media: List<MediaItem>) {
        val nonVaulted = media.filter { !it.isVaulted }
        val filtered = filterMedia(nonVaulted, _uiState.value.selectedFilter, _uiState.value.searchQuery)
        val timeline = repository.groupMediaByTimeline(filtered)
        val albums = repository.extractAlbums(nonVaulted)

        _uiState.update {
            it.copy(
                allMedia = media,
                filteredMedia = filtered,
                timelineGroups = timeline,
                albums = albums
            )
        }
    }

    private fun filterMedia(
        list: List<MediaItem>,
        filter: MediaFilterType,
        query: String
    ): List<MediaItem> {
        var result = list
        if (query.isNotBlank()) {
            val q = query.trim().lowercase()
            result = result.filter {
                it.displayName.lowercase().contains(q) ||
                        it.bucketName.lowercase().contains(q)
            }
        }
        return when (filter) {
            MediaFilterType.ALL -> result
            MediaFilterType.PHOTOS -> result.filter { !it.isVideo }
            MediaFilterType.VIDEOS -> result.filter { it.isVideo }
            MediaFilterType.FAVORITES -> result.filter { it.isFavorite }
            MediaFilterType.EDITS -> result.filter { it.bucketName == "Gal X Edits" }
        }
    }

    fun onSearchQueryChanged(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
        updateMediaCollections(_uiState.value.allMedia)
    }

    fun onFilterChanged(filter: MediaFilterType) {
        _uiState.update { it.copy(selectedFilter = filter) }
        updateMediaCollections(_uiState.value.allMedia)
    }

    fun setDensity(density: ViewDensity) {
        _uiState.update { it.copy(viewDensity = density) }
    }

    fun setAccentColor(color: Color) {
        _uiState.update { it.copy(accentColor = color) }
    }

    fun setTab(tab: GalleryTab) {
        _uiState.update { it.copy(currentTab = tab) }
    }

    fun navigateTo(screen: Screen) {
        _uiState.update { it.copy(currentScreen = screen) }
    }

    fun navigateBack() {
        _uiState.update { state ->
            val nextScreen = when (state.currentScreen) {
                is Screen.Viewer -> Screen.Gallery
                is Screen.Editor -> Screen.Viewer((state.currentScreen as Screen.Editor).item)
                is Screen.AlbumDetail -> Screen.Gallery
                is Screen.Vault -> Screen.Gallery
                else -> Screen.Gallery
            }
            state.copy(currentScreen = nextScreen)
        }
    }

    fun toggleFavorite(item: MediaItem) {
        val newFav = repository.toggleFavorite(item.id)
        val updated = _uiState.value.allMedia.map {
            if (it.id == item.id) it.copy(isFavorite = newFav) else it
        }
        updateMediaCollections(updated)
        // If current screen is viewer, update item
        val current = _uiState.value.currentScreen
        if (current is Screen.Viewer && current.item.id == item.id) {
            _uiState.update { it.copy(currentScreen = Screen.Viewer(item.copy(isFavorite = newFav))) }
        }
        showToast(if (newFav) "Added to Favorites ♥" else "Removed from Favorites")
    }

    fun toggleVault(item: MediaItem) {
        val isNowVaulted = repository.toggleVault(item.id)
        val updated = _uiState.value.allMedia.map {
            if (it.id == item.id) it.copy(isVaulted = isNowVaulted) else it
        }
        updateMediaCollections(updated)
        showToast(if (isNowVaulted) "Locked into Secret Vault 🔒" else "Restored to Gallery")
        if (_uiState.value.currentScreen is Screen.Viewer) {
            navigateTo(Screen.Gallery)
        }
    }

    fun addImportedMedia(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val newItems = uris.mapIndexed { index, uri ->
                MediaItem(
                    id = now + index,
                    uri = uri,
                    displayName = "GALX_Import_${index + 1}.jpg",
                    dateAdded = now / 1000L,
                    size = 2_500_000L,
                    mimeType = "image/jpeg",
                    isVideo = false,
                    width = 1920,
                    height = 1080,
                    bucketName = "Imported",
                    isFavorite = false,
                    isVaulted = false,
                    isSample = false
                )
            }
            val updated = newItems + _uiState.value.allMedia
            updateMediaCollections(updated)
            showToast("Imported ${uris.size} item(s) to Gal X")
        }
    }

    fun deleteItem(item: MediaItem) {
        val updated = _uiState.value.allMedia.filter { it.id != item.id }
        updateMediaCollections(updated)
        if (_uiState.value.currentScreen is Screen.Viewer) {
            navigateTo(Screen.Gallery)
        }
        showToast("Item deleted")
    }

    fun toggleItemSelection(id: Long) {
        val currentSelected = _uiState.value.selectedItemIds.toMutableSet()
        if (currentSelected.contains(id)) {
            currentSelected.remove(id)
        } else {
            currentSelected.add(id)
        }
        _uiState.update {
            it.copy(
                selectedItemIds = currentSelected,
                isSelectionMode = currentSelected.isNotEmpty()
            )
        }
    }

    fun clearSelection() {
        _uiState.update {
            it.copy(
                selectedItemIds = emptySet(),
                isSelectionMode = false
            )
        }
    }

    fun deleteSelected() {
        val idsToDelete = _uiState.value.selectedItemIds
        val updated = _uiState.value.allMedia.filter { !idsToDelete.contains(it.id) }
        updateMediaCollections(updated)
        clearSelection()
        showToast("Deleted ${idsToDelete.size} items")
    }

    fun saveEditedPhoto(originalItem: MediaItem, editedBitmap: Bitmap) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val newItem = repository.saveEditedBitmap(editedBitmap, originalItem.displayName)
            val updated = listOf(newItem) + _uiState.value.allMedia
            updateMediaCollections(updated)
            _uiState.update { it.copy(isLoading = false) }
            showToast("Neon Edit Saved to Gal X!")
            navigateTo(Screen.Viewer(newItem))
        }
    }

    fun unlockVault(pin: String): Boolean {
        if (pin == _uiState.value.vaultPin) {
            _uiState.update { it.copy(isVaultUnlocked = true) }
            return true
        }
        return false
    }

    fun lockVault() {
        _uiState.update { it.copy(isVaultUnlocked = false) }
    }

    fun setVaultPin(newPin: String) {
        _uiState.update { it.copy(vaultPin = newPin) }
        showToast("Vault PIN updated")
    }

    fun showToast(msg: String) {
        _uiState.update { it.copy(statusMessage = msg) }
    }

    fun clearToast() {
        _uiState.update { it.copy(statusMessage = null) }
    }
}
