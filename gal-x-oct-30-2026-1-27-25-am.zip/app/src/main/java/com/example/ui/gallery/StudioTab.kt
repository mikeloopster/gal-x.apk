package com.example.ui.gallery

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.Flare
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MediaItem
import com.example.ui.theme.GalXAccentPurple
import com.example.ui.theme.GalXBorderLight
import com.example.ui.theme.GalXSurfaceCard
import com.example.ui.theme.GalXTextMuted
import com.example.ui.theme.GalXTextPrimary
import com.example.ui.theme.GalXTextSecondary
import com.example.ui.theme.NeonBluePrimary
import com.example.ui.theme.NeonCyanAccent

@Composable
fun StudioTab(
    mediaList: List<MediaItem>,
    accentColor: Color,
    onLaunchEditor: (MediaItem) -> Unit,
    onOpenVault: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val topItem = mediaList.firstOrNull()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 100.dp)
    ) {
        // Welcome Card
        Card(
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = GalXSurfaceCard),
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    width = 1.dp,
                    brush = Brush.linearGradient(listOf(NeonCyanAccent, NeonBluePrimary)),
                    shape = RoundedCornerShape(22.dp)
                )
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.radialGradient(
                            listOf(Color(0xFF132247), Color(0xFF0F172A))
                        )
                    )
                    .padding(20.dp)
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(NeonCyanAccent.copy(alpha = 0.2f))
                                .border(1.dp, NeonCyanAccent, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = NeonCyanAccent,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Gal X Photo Studio",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = GalXTextPrimary
                            )
                            Text(
                                text = "Easy photo editing, drawing & privacy",
                                fontSize = 12.sp,
                                color = NeonCyanAccent
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Customize your pictures with lovely filters, draw glowing doodles with the neon pen, or keep private moments protected.",
                        fontSize = 13.sp,
                        color = GalXTextSecondary,
                        lineHeight = 18.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(22.dp))

        Text(
            text = "CREATIVE TOOLS",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = GalXTextMuted,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Tool 1: Full Photo Editor
        FriendlyToolCard(
            title = "Photo Editor & Adjustments",
            subtitle = "Crop, straighten, adjust brightness, and apply color styles",
            icon = Icons.Default.Crop,
            accent = NeonCyanAccent,
            badge = "Editor",
            testTag = "open_photo_editor_tool",
            onClick = {
                if (topItem != null) onLaunchEditor(topItem)
            }
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Tool 2: Neon Doodle Pen
        FriendlyToolCard(
            title = "Neon Glow Doodle Pen",
            subtitle = "Add colorful glowing handwriting and playful doodles to any photo",
            icon = Icons.Default.Brush,
            accent = Color(0xFF38BDF8),
            badge = "Fun",
            testTag = "open_brush_tool",
            onClick = {
                if (topItem != null) onLaunchEditor(topItem)
            }
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Tool 3: Magic Glow Aura
        FriendlyToolCard(
            title = "Magic Glow Accent",
            subtitle = "Surround your favorite shots with a gentle glowing light aura",
            icon = Icons.Default.Flare,
            accent = Color(0xFF00E5FF),
            badge = "Glow",
            testTag = "open_aura_fx_tool",
            onClick = {
                if (topItem != null) onLaunchEditor(topItem)
            }
        )

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "PRIVACY",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = GalXTextMuted,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Tool 4: Private Album
        FriendlyToolCard(
            title = "Private Album",
            subtitle = "Keep personal memories safe behind a 4-digit PIN passcode",
            icon = Icons.Default.Lock,
            accent = GalXAccentPurple,
            badge = "Secure",
            testTag = "open_vault_tool",
            onClick = onOpenVault
        )
    }
}

@Composable
fun FriendlyToolCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accent: Color,
    badge: String,
    testTag: String,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = GalXSurfaceCard),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(0.8.dp, GalXBorderLight, RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(accent.copy(alpha = 0.15f))
                    .border(1.dp, accent.copy(alpha = 0.5f), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accent,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = title,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = GalXTextPrimary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(accent.copy(alpha = 0.2f))
                            .padding(horizontal = 7.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = badge,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = accent
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = subtitle,
                    fontSize = 12.sp,
                    color = GalXTextSecondary,
                    lineHeight = 16.sp
                )
            }
        }
    }
}
