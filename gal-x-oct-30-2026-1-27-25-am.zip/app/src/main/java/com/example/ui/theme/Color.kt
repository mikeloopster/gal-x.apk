package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Gal X - Modern Neon Blue Consumer Palette
val NeonBluePrimary = Color(0xFF00B4D8)
val NeonCyanAccent = Color(0xFF00F0FF)
val NeonElectricSky = Color(0xFF38BDF8)
val NeonCobalt = Color(0xFF0077B6)
val SoftNeonGlow = Color(0x3300F0FF)

// Backgrounds & Surfaces (Soft, elegant sapphire midnight instead of harsh terminal black)
val GalXDeepNavy = Color(0xFF090E1A)
val GalXSurfaceDark = Color(0xFF0F172A)
val GalXSurfaceCard = Color(0xFF1E293B)
val GalXSurfaceElevated = Color(0xFF27354E)
val GalXSurfaceHighlight = Color(0xFF334155)

// Borders & Dividers
val GalXBorderLight = Color(0x2E38BDF8)
val GalXBorderGlowing = Color(0x5500F0FF)

// Text Colors (High legibility, warm and clean)
val GalXTextPrimary = Color(0xFFF8FAFC)
val GalXTextSecondary = Color(0xFF94A3B8)
val GalXTextMuted = Color(0xFF64748B)

// Accent Colors for tags and highlights
val GalXHeartPink = Color(0xFFFF4D8D)
val GalXAccentMint = Color(0xFF10B981)
val GalXAccentAmber = Color(0xFFF59E0B)
val GalXAccentPurple = Color(0xFF8B5CF6)

// Aliases for clean compatibility
val NeonCyan = NeonCyanAccent
val NeonPink = GalXHeartPink
val NeonBlue = NeonBluePrimary
val NeonViolet = GalXAccentPurple
val NeonTeal = GalXAccentMint
val SurfaceCard = GalXSurfaceCard
val SurfaceDark = GalXSurfaceDark
val TextPrimary = GalXTextPrimary
val TextSecondary = GalXTextSecondary
val TextMuted = GalXTextMuted
val DarkNavyBg = GalXDeepNavy
