package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val GalXDarkColorScheme = darkColorScheme(
    primary = NeonCyanAccent,
    onPrimary = Color(0xFF03101E),
    primaryContainer = Color(0xFF0369A1),
    onPrimaryContainer = Color(0xFFE0F2FE),
    secondary = NeonBluePrimary,
    onSecondary = Color(0xFF031429),
    secondaryContainer = Color(0xFF1E3A8A),
    onSecondaryContainer = Color(0xFFDBEAFE),
    tertiary = NeonElectricSky,
    onTertiary = Color(0xFF021B26),
    background = GalXDeepNavy,
    onBackground = GalXTextPrimary,
    surface = GalXSurfaceDark,
    onSurface = GalXTextPrimary,
    surfaceVariant = GalXSurfaceCard,
    onSurfaceVariant = GalXTextSecondary,
    outline = GalXBorderLight,
    outlineVariant = GalXBorderGlowing
)

@Composable
fun GalXTheme(
    accentColor: Color = NeonCyanAccent,
    content: @Composable () -> Unit
) {
    val dynamicScheme = if (accentColor == NeonCyanAccent) {
        GalXDarkColorScheme
    } else {
        GalXDarkColorScheme.copy(
            primary = accentColor,
            primaryContainer = accentColor.copy(alpha = 0.25f),
            onPrimaryContainer = Color.White
        )
    }

    MaterialTheme(
        colorScheme = dynamicScheme,
        typography = Typography,
        content = content
    )
}
