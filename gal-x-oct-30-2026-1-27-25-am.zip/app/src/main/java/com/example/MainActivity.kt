package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.GalXViewModel
import com.example.ui.Screen
import com.example.ui.editor.PhotoEditorScreen
import com.example.ui.gallery.AlbumDetailScreen
import com.example.ui.gallery.GalleryMainScreen
import com.example.ui.splash.SplashScreen
import com.example.ui.theme.DarkNavyBg
import com.example.ui.theme.GalXTheme
import com.example.ui.vault.SecretVaultScreen
import com.example.ui.viewer.MediaViewerScreen

class MainActivity : ComponentActivity() {

    private val viewModel: GalXViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()

            GalXTheme(accentColor = uiState.accentColor) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = DarkNavyBg
                ) {
                    when (val screen = uiState.currentScreen) {
                        is Screen.Splash -> {
                            SplashScreen(
                                onSplashFinished = {
                                    viewModel.navigateTo(Screen.Gallery)
                                }
                            )
                        }

                        is Screen.Gallery -> {
                            GalleryMainScreen(
                                viewModel = viewModel,
                                uiState = uiState
                            )
                        }

                        is Screen.Viewer -> {
                            MediaViewerScreen(
                                item = screen.item,
                                accentColor = uiState.accentColor,
                                onBack = { viewModel.navigateBack() },
                                onToggleFavorite = { viewModel.toggleFavorite(it) },
                                onToggleVault = { viewModel.toggleVault(it) },
                                onEdit = { viewModel.navigateTo(Screen.Editor(it)) },
                                onDelete = { viewModel.deleteItem(it) }
                            )
                        }

                        is Screen.Editor -> {
                            PhotoEditorScreen(
                                item = screen.item,
                                accentColor = uiState.accentColor,
                                onBack = { viewModel.navigateBack() },
                                onSaveSuccess = { editedBitmap ->
                                    viewModel.saveEditedPhoto(screen.item, editedBitmap)
                                }
                            )
                        }

                        is Screen.AlbumDetail -> {
                            AlbumDetailScreen(
                                albumName = screen.albumName,
                                allMedia = uiState.allMedia,
                                viewDensity = uiState.viewDensity,
                                accentColor = uiState.accentColor,
                                onBack = { viewModel.navigateBack() },
                                onItemClick = { viewModel.navigateTo(Screen.Viewer(it)) }
                            )
                        }

                        is Screen.Vault -> {
                            SecretVaultScreen(
                                allMedia = uiState.allMedia,
                                isUnlocked = uiState.isVaultUnlocked,
                                onUnlock = { pin -> viewModel.unlockVault(pin) },
                                onLock = { viewModel.lockVault() },
                                onBack = { viewModel.navigateBack() },
                                onItemClick = { viewModel.navigateTo(Screen.Viewer(it)) },
                                onToggleVault = { viewModel.toggleVault(it) },
                                accentColor = uiState.accentColor
                            )
                        }
                    }
                }
            }
        }
    }
}
