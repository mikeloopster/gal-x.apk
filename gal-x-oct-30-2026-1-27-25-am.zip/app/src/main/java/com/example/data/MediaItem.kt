package com.example.data

import android.net.Uri
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

data class MediaItem(
    val id: Long,
    val uri: Uri,
    val displayName: String,
    val dateAdded: Long, // seconds
    val size: Long,
    val mimeType: String,
    val isVideo: Boolean = false,
    val durationMs: Long = 0L,
    val width: Int = 0,
    val height: Int = 0,
    val bucketName: String = "Gallery",
    val isFavorite: Boolean = false,
    val isVaulted: Boolean = false,
    val customTags: List<String> = emptyList(),
    val isSample: Boolean = false
) {
    val formattedDate: String
        get() {
            val date = Date(if (dateAdded > 100000000000L) dateAdded else dateAdded * 1000L)
            return SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(date)
        }

    val formattedTime: String
        get() {
            val date = Date(if (dateAdded > 100000000000L) dateAdded else dateAdded * 1000L)
            return SimpleDateFormat("h:mm a", Locale.getDefault()).format(date)
        }

    val formattedSize: String
        get() {
            if (size <= 0) return "0 B"
            val units = arrayOf("B", "KB", "MB", "GB")
            val digitGroups = (Math.log10(size.toDouble()) / Math.log10(1024.0)).toInt()
            val finalGroup = digitGroups.coerceIn(0, units.size - 1)
            return String.format(Locale.US, "%.1f %s", size / Math.pow(1024.0, finalGroup.toDouble()), units[finalGroup])
        }

    val formattedDuration: String
        get() {
            if (!isVideo || durationMs <= 0) return ""
            val minutes = TimeUnit.MILLISECONDS.toMinutes(durationMs)
            val seconds = TimeUnit.MILLISECONDS.toSeconds(durationMs) - TimeUnit.MINUTES.toSeconds(minutes)
            return String.format(Locale.US, "%d:%02d", minutes, seconds)
        }

    val resolutionString: String
        get() = if (width > 0 && height > 0) "${width} × ${height}" else "HD"

    val megapixels: String
        get() = if (width > 0 && height > 0) {
            val mp = (width.toDouble() * height.toDouble()) / 1_000_000.0
            String.format(Locale.US, "%.1f MP", mp)
        } else "High-Res"
}

data class MediaAlbum(
    val name: String,
    val coverUri: Uri?,
    val itemCount: Int,
    val isSystem: Boolean = false,
    val isVideoAlbum: Boolean = false,
    val isFavoriteAlbum: Boolean = false,
    val isVaultAlbum: Boolean = false
)

data class TimelineGroup(
    val headerTitle: String,
    val dateKey: String,
    val items: List<MediaItem>
)

enum class ViewDensity(val columns: Int, val label: String) {
    COMFORTABLE(2, "2 Col (Large)"),
    STANDARD(3, "3 Col (Default)"),
    COMPACT(4, "4 Col (Compact)"),
    DENSE(5, "5 Col (Micro)")
}

enum class MediaFilterType(val label: String) {
    ALL("All"),
    PHOTOS("Photos"),
    VIDEOS("Videos"),
    FAVORITES("Favorites"),
    EDITS("Gal X Edits")
}
