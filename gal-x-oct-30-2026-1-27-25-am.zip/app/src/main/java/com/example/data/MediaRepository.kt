package com.example.data

import android.content.ContentUris
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MediaRepository(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("gal_x_prefs", Context.MODE_PRIVATE)

    private val favoriteIdsKey = "favorite_ids"
    private val vaultIdsKey = "vault_ids"

    private fun getFavoriteIds(): MutableSet<String> {
        return try {
            prefs.getStringSet(favoriteIdsKey, emptySet())?.toMutableSet() ?: mutableSetOf()
        } catch (e: Exception) {
            mutableSetOf()
        }
    }

    private fun getVaultIds(): MutableSet<String> {
        return try {
            prefs.getStringSet(vaultIdsKey, emptySet())?.toMutableSet() ?: mutableSetOf()
        } catch (e: Exception) {
            mutableSetOf()
        }
    }

    fun isFavorite(id: Long): Boolean {
        return getFavoriteIds().contains(id.toString())
    }

    fun toggleFavorite(id: Long): Boolean {
        val favs = getFavoriteIds()
        val key = id.toString()
        val newState = if (favs.contains(key)) {
            favs.remove(key)
            false
        } else {
            favs.add(key)
            true
        }
        prefs.edit().putStringSet(favoriteIdsKey, favs).apply()
        return newState
    }

    fun isVaulted(id: Long): Boolean {
        return getVaultIds().contains(id.toString())
    }

    fun toggleVault(id: Long): Boolean {
        val vault = getVaultIds()
        val key = id.toString()
        val newState = if (vault.contains(key)) {
            vault.remove(key)
            false
        } else {
            vault.add(key)
            true
        }
        prefs.edit().putStringSet(vaultIdsKey, vault).apply()
        return newState
    }

    suspend fun loadDeviceMedia(): List<MediaItem> = withContext(Dispatchers.IO) {
        val mediaList = mutableListOf<MediaItem>()
        val favIds = getFavoriteIds()
        val vaultIds = getVaultIds()

        // 1. Fetch Images from MediaStore with safe column indexing
        try {
            val imageProjection = arrayOf(
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.DATE_ADDED,
                MediaStore.Images.Media.SIZE,
                MediaStore.Images.Media.MIME_TYPE,
                MediaStore.Images.Media.WIDTH,
                MediaStore.Images.Media.HEIGHT,
                MediaStore.Images.Media.BUCKET_DISPLAY_NAME
            )

            val imageSortOrder = "${MediaStore.Images.Media.DATE_ADDED} DESC"

            context.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                imageProjection,
                null,
                null,
                imageSortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndex(MediaStore.Images.Media._ID)
                val nameCol = cursor.getColumnIndex(MediaStore.Images.Media.DISPLAY_NAME)
                val dateCol = cursor.getColumnIndex(MediaStore.Images.Media.DATE_ADDED)
                val sizeCol = cursor.getColumnIndex(MediaStore.Images.Media.SIZE)
                val mimeCol = cursor.getColumnIndex(MediaStore.Images.Media.MIME_TYPE)
                val widthCol = cursor.getColumnIndex(MediaStore.Images.Media.WIDTH)
                val heightCol = cursor.getColumnIndex(MediaStore.Images.Media.HEIGHT)
                val bucketCol = cursor.getColumnIndex(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)

                while (cursor.moveToNext()) {
                    if (idCol == -1) break
                    val id = cursor.getLong(idCol)
                    val uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)
                    val name = if (nameCol != -1) cursor.getString(nameCol) ?: "Photo_$id.jpg" else "Photo_$id.jpg"
                    val dateAdded = if (dateCol != -1) cursor.getLong(dateCol) else System.currentTimeMillis() / 1000L
                    val size = if (sizeCol != -1) cursor.getLong(sizeCol) else 0L
                    val mime = if (mimeCol != -1) cursor.getString(mimeCol) ?: "image/jpeg" else "image/jpeg"
                    val width = if (widthCol != -1) cursor.getInt(widthCol) else 0
                    val height = if (heightCol != -1) cursor.getInt(heightCol) else 0
                    val bucket = if (bucketCol != -1) cursor.getString(bucketCol) ?: "Camera" else "Camera"

                    mediaList.add(
                        MediaItem(
                            id = id,
                            uri = uri,
                            displayName = name,
                            dateAdded = dateAdded,
                            size = size,
                            mimeType = mime,
                            isVideo = false,
                            width = width,
                            height = height,
                            bucketName = bucket,
                            isFavorite = favIds.contains(id.toString()),
                            isVaulted = vaultIds.contains(id.toString()),
                            isSample = false
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // 2. Fetch Videos from MediaStore with safe column indexing
        try {
            val videoProjection = arrayOf(
                MediaStore.Video.Media._ID,
                MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.DATE_ADDED,
                MediaStore.Video.Media.SIZE,
                MediaStore.Video.Media.MIME_TYPE,
                MediaStore.Video.Media.DURATION,
                MediaStore.Video.Media.WIDTH,
                MediaStore.Video.Media.HEIGHT,
                MediaStore.Video.Media.BUCKET_DISPLAY_NAME
            )

            val videoSortOrder = "${MediaStore.Video.Media.DATE_ADDED} DESC"

            context.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                videoProjection,
                null,
                null,
                videoSortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndex(MediaStore.Video.Media._ID)
                val nameCol = cursor.getColumnIndex(MediaStore.Video.Media.DISPLAY_NAME)
                val dateCol = cursor.getColumnIndex(MediaStore.Video.Media.DATE_ADDED)
                val sizeCol = cursor.getColumnIndex(MediaStore.Video.Media.SIZE)
                val mimeCol = cursor.getColumnIndex(MediaStore.Video.Media.MIME_TYPE)
                val durCol = cursor.getColumnIndex(MediaStore.Video.Media.DURATION)
                val widthCol = cursor.getColumnIndex(MediaStore.Video.Media.WIDTH)
                val heightCol = cursor.getColumnIndex(MediaStore.Video.Media.HEIGHT)
                val bucketCol = cursor.getColumnIndex(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)

                while (cursor.moveToNext()) {
                    if (idCol == -1) break
                    val id = cursor.getLong(idCol)
                    val uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
                    val name = if (nameCol != -1) cursor.getString(nameCol) ?: "Video_$id.mp4" else "Video_$id.mp4"
                    val dateAdded = if (dateCol != -1) cursor.getLong(dateCol) else System.currentTimeMillis() / 1000L
                    val size = if (sizeCol != -1) cursor.getLong(sizeCol) else 0L
                    val mime = if (mimeCol != -1) cursor.getString(mimeCol) ?: "video/mp4" else "video/mp4"
                    val duration = if (durCol != -1) cursor.getLong(durCol) else 0L
                    val width = if (widthCol != -1) cursor.getInt(widthCol) else 0
                    val height = if (heightCol != -1) cursor.getInt(heightCol) else 0
                    val bucket = if (bucketCol != -1) cursor.getString(bucketCol) ?: "Videos" else "Videos"

                    mediaList.add(
                        MediaItem(
                            id = id,
                            uri = uri,
                            displayName = name,
                            dateAdded = dateAdded,
                            size = size,
                            mimeType = mime,
                            isVideo = true,
                            durationMs = duration,
                            width = width,
                            height = height,
                            bucketName = bucket,
                            isFavorite = favIds.contains(id.toString()),
                            isVaulted = vaultIds.contains(id.toString()),
                            isSample = false
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // 3. Scan app internal edits directory
        try {
            val editsDir = File(context.filesDir, "galx_edits")
            if (editsDir.exists()) {
                val files = editsDir.listFiles()
                files?.forEachIndexed { index, file ->
                    val id = 10_000_000L + index
                    val uri = Uri.fromFile(file)
                    mediaList.add(
                        MediaItem(
                            id = id,
                            uri = uri,
                            displayName = file.name,
                            dateAdded = file.lastModified() / 1000L,
                            size = file.length(),
                            mimeType = "image/jpeg",
                            isVideo = false,
                            width = 1920,
                            height = 1080,
                            bucketName = "Gal X Edits",
                            isFavorite = favIds.contains(id.toString()),
                            isVaulted = vaultIds.contains(id.toString()),
                            isSample = false
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        mediaList.sortedByDescending { it.dateAdded }
    }

    suspend fun saveEditedBitmap(bitmap: Bitmap, originalName: String): MediaItem = withContext(Dispatchers.IO) {
        val editsDir = File(context.filesDir, "galx_edits")
        if (!editsDir.exists()) editsDir.mkdirs()

        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val fileName = "GalX_Edit_${timestamp}.jpg"
        val destFile = File(editsDir, fileName)

        FileOutputStream(destFile).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)
        }

        val id = System.currentTimeMillis()
        MediaItem(
            id = id,
            uri = Uri.fromFile(destFile),
            displayName = fileName,
            dateAdded = System.currentTimeMillis() / 1000L,
            size = destFile.length(),
            mimeType = "image/jpeg",
            isVideo = false,
            width = bitmap.width,
            height = bitmap.height,
            bucketName = "Gal X Edits",
            isFavorite = false,
            isVaulted = false,
            isSample = false
        )
    }

    fun groupMediaByTimeline(items: List<MediaItem>): List<TimelineGroup> {
        val calendar = Calendar.getInstance()
        val todayYear = calendar.get(Calendar.YEAR)
        val todayDayOfYear = calendar.get(Calendar.DAY_OF_YEAR)

        val groups = items.groupBy { item ->
            val itemDate = Date(if (item.dateAdded > 100000000000L) item.dateAdded else item.dateAdded * 1000L)
            calendar.time = itemDate
            val itemYear = calendar.get(Calendar.YEAR)
            val itemDayOfYear = calendar.get(Calendar.DAY_OF_YEAR)

            when {
                itemYear == todayYear && itemDayOfYear == todayDayOfYear -> "Today"
                itemYear == todayYear && itemDayOfYear == todayDayOfYear - 1 -> "Yesterday"
                itemYear == todayYear && todayDayOfYear - itemDayOfYear in 2..6 -> "This Week"
                else -> SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(itemDate)
            }
        }

        return groups.map { (header, list) ->
            TimelineGroup(
                headerTitle = header,
                dateKey = header,
                items = list
            )
        }
    }

    fun extractAlbums(items: List<MediaItem>): List<MediaAlbum> {
        val albums = mutableListOf<MediaAlbum>()

        // Favorites Album
        val favCount = items.count { it.isFavorite }
        val favCover = items.firstOrNull { it.isFavorite }?.uri
        albums.add(
            MediaAlbum(
                name = "Favorites",
                coverUri = favCover ?: items.firstOrNull()?.uri,
                itemCount = favCount,
                isSystem = true,
                isFavoriteAlbum = true
            )
        )

        // Videos Album
        val videoCount = items.count { it.isVideo }
        val videoCover = items.firstOrNull { it.isVideo }?.uri
        albums.add(
            MediaAlbum(
                name = "Videos",
                coverUri = videoCover ?: items.firstOrNull()?.uri,
                itemCount = videoCount,
                isSystem = true,
                isVideoAlbum = true
            )
        )

        // Real bucket albums (e.g., Camera, Screenshots, Vacations, etc.)
        val buckets = items.groupBy { it.bucketName }
        buckets.forEach { (bucketName, bucketItems) ->
            albums.add(
                MediaAlbum(
                    name = bucketName,
                    coverUri = bucketItems.firstOrNull()?.uri,
                    itemCount = bucketItems.size,
                    isSystem = false
                )
            )
        }

        return albums
    }
}
