package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.MediaFilterType
import com.example.data.MediaRepository
import com.example.data.ViewDensity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read app name string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Gal X", appName)
  }

  @Test
  fun `read author tagline string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val tagline = context.getString(R.string.author_tagline)
    assertEquals("Production of Evanson Marechu", tagline)
  }

  @Test
  fun `verify media repository and filters`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repo = MediaRepository(context)
    assertNotNull(repo)
    assertEquals(4, ViewDensity.values().size)
    assertEquals(5, MediaFilterType.values().size)
  }
}
